﻿//@BaseCode

namespace SmartNQuick.Contracts
{
	public partial interface IIdentifiable
	{
		int Id { get; }
	}
}
