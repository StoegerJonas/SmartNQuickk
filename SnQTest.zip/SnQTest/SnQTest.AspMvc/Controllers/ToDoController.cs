﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SnQTest.AspMvc.Controllers
{
    public class ToDoController : GenericModelController<SnQTest.Contracts.Persistence.ToDoList.IToDo, SnQTest.AspMvc.Models.ToDoList.ToDo>
    {
     
      

        // GET: ToDoController/Create
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            using var ctrl = Logic.Factory.Create<Contracts.Persistence.ToDoList.IToDo>();
            var entity = await ctrl.CreateAsync().ConfigureAwait(false);

            return View(ToModel(entity));
        }
        [HttpPost]
        public async Task<IActionResult> Insert(Models.ToDoList.ToDo model)
        {
            using var ctrl = Logic.Factory.Create<Contracts.Persistence.ToDoList.IToDo>();

            await ctrl.InsertAsync(model).ConfigureAwait(false);
            await ctrl.SaveChangesAsync().ConfigureAwait(false);
            return RedirectToAction("Index");
        }



        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            using var ctrl = Logic.Factory.Create<Contracts.Persistence.ToDoList.IToDo>();
            var entity = await ctrl.GetByIdAsync(id).ConfigureAwait(false);

            return View(ToModel(entity));
        }

        [HttpPost]
        public async Task<IActionResult> Update(Models.ToDoList.ToDo model)
        {
            using var ctrl = Logic.Factory.Create<Contracts.Persistence.ToDoList.IToDo>();
            var entity = await ctrl.GetByIdAsync(model.Id).ConfigureAwait(false);

            if(entity != null)
            {
                entity.Title = model.Title;
                entity.Description = model.Description;
                entity.Date = model.Date;
               
                await ctrl.UpdateAsync(entity).ConfigureAwait(false);
                await ctrl.SaveChangesAsync().ConfigureAwait(false);

            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            using var ctrl = Logic.Factory.Create<Contracts.Persistence.ToDoList.IToDo>();
            var entity = await ctrl.GetByIdAsync(id).ConfigureAwait(false);

            return View(ToModel(entity));
        }
        public async Task<IActionResult> DeleteEntity(int id)
        {
            using var ctrl = Logic.Factory.Create<Contracts.Persistence.ToDoList.IToDo>();

            await ctrl.DeleteAsync(id).ConfigureAwait(false);
            await ctrl.SaveChangesAsync().ConfigureAwait(false);

            return RedirectToAction("Index");
        }
        



    }
}
