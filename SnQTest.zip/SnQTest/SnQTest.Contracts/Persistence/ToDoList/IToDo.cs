﻿using CommonBase.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnQTest.Contracts.Persistence.ToDoList
{
    [ContractInfo(ContextType = ContextType.Table)]
    public partial interface IToDo : IVersionable, ICopyable<IToDo>
    {
        [ContractPropertyInfo(Required =true, MaxLength =128,IsUnique =true)]
        string Title { get; set; }
        [ContractPropertyInfo(Required = true, MaxLength = 516, IsUnique = false)]
        string Description { get; set; }
        [ContractPropertyInfo(Required = true, IsUnique = false)]
        DateTime Date { get; set; }

    }
}
