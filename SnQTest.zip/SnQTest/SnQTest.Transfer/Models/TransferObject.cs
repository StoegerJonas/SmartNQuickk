//@CodeCopy
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnQTest.Transfer.Models
{
	public partial class TransferObject
	{
	}
}
