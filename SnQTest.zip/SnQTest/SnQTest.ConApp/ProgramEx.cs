﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnQTest.ConApp
{
    partial class Program
    {
        static async partial void BeforeRun()
        {
            using var toDoCtrl = Logic.Factory.Create<Contracts.Persistence.ToDoList.IToDo>();

            for (int i = 0; i < 10; i++)
            {
                var toDo = await toDoCtrl.CreateAsync();

                toDo.Title = $"Title - {Guid.NewGuid()}";
                toDo.Description = $"Description - {Guid.NewGuid()}";
                toDo.Date = DateTime.Now;
                await toDoCtrl.InsertAsync(toDo);

            }
            await toDoCtrl.SaveChangesAsync();
        }


    }
}
