﻿using Microsoft.EntityFrameworkCore;
using SnQTest.Contracts.Persistence.ToDoList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnQTest.Logic.DataContext
{
    partial class ProjectDbContext
    {
        public DbSet<Entities.ToDoList.ToDo> ToDos { get; set; }

        partial void GetDbSet<C, E>(ref DbSet<E> dbset) where E : class
        {
            if(typeof(C) == typeof(IToDo))
            {
                dbset = ToDos as DbSet<E>;
            }
        }
        partial void BeforeOnModelCreating(ModelBuilder modelBuilder, ref bool handled)
        {
            var toDoBuilder = modelBuilder.Entity<Entities.ToDoList.ToDo>();

            toDoBuilder.HasKey(p => p.Id);
            toDoBuilder.Property(p => p.RowVersion).IsRowVersion();
            toDoBuilder.Property(p => p.Title).IsRequired().HasMaxLength(128);
            toDoBuilder.Property(p => p.Description).IsRequired().HasMaxLength(516);
            toDoBuilder.Property(p => p.Date).IsRequired();
        }
    }
}
