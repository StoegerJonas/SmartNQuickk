﻿using SnQTest.Contracts.Persistence.ToDoList;
using SnQTest.Logic.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnQTest.Logic.Controllers.Persistence.ToDoList
{
    class ToDoController : GenericPersistenceController<SnQTest.Contracts.Persistence.ToDoList.IToDo, SnQTest.Logic.Entities.ToDoList.ToDo>
    {
		public ToDoController(IContext context) : base(context)
		{
		}

		public ToDoController(ControllerObject other) : base(other)
		{
		}

		private void CheckToDo(IToDo item)
        {
			if(item.Title.Length > 128)
            {
				throw new Exception("is lenga wia dei bibal");
            }
        }
		public override Task<IToDo> InsertAsync(IToDo entity)
		{
			CheckToDo(entity);

			return base.InsertAsync(entity);
		}
		public override Task<IToDo> UpdateAsync(IToDo entity)
		{
			CheckToDo(entity);

			return base.UpdateAsync(entity);
		}
	}
}
