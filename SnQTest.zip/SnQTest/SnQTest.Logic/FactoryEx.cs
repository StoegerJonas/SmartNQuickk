﻿using SnQTest.Contracts;
using SnQTest.Contracts.Client;
using SnQTest.Logic.Contracts;
using SnQTest.Logic.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnQTest.Logic
{
    partial class Factory
    {
        static partial void CreateController<C>(IContext context, ref IControllerAccess<C> controller) where C : IIdentifiable
        {
            if (typeof(C) == typeof(SnQTest.Contracts.Persistence.ToDoList.IToDo))
            {
                controller = new Controllers.Persistence.ToDoList.ToDoController(context) as IControllerAccess<C>;
            }
        }
        static partial void CreateController<C>(ControllerObject controllerObject, ref IControllerAccess<C> controller) where C : IIdentifiable
        {
            if (typeof(C) == typeof(SnQTest.Contracts.Persistence.ToDoList.IToDo))
            {
                controller = new Controllers.Persistence.ToDoList.ToDoController(controllerObject) as IControllerAccess<C>;
            }
        }
    }
}
