//@CodeCopy

using SnQTest.Contracts;

namespace SnQTest.Logic.Entities
{
	internal abstract partial class VersionEntity : IdentityEntity, IVersionable
	{
		public byte[] RowVersion { get; set; }
	}
}
