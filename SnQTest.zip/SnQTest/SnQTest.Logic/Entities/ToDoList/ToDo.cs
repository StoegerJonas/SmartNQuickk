﻿using CommonBase.Extensions;
using SnQTest.Contracts.Persistence.ToDoList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnQTest.Logic.Entities.ToDoList
{
    class ToDo : VersionEntity, SnQTest.Contracts.Persistence.ToDoList.IToDo
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Date { get; set; }

        public void CopyProperties(IToDo other)
        {


            other.CheckArgument(nameof(other));

            Id = other.Id;
            RowVersion = other.RowVersion;
            Title = other.Title;
            Description = other.Description;
            Date = other.Date;
        }
    }
}
