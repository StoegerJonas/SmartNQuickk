//@CodeCopy

using CommonBase.Extensions;
using SnQTest.Contracts;

namespace SnQTest.Logic.Entities
{
	internal abstract partial class IdentityEntity : IIdentifiable
	{
		public int Id { get; set; }
	}
}
